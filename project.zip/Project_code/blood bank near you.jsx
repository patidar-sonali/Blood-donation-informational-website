<!DOCTYPE html>
<html lang=<"en">
   
import React, { useState } from 'react';

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name=""viewport" content=""width=device-width,initial-scale=1.0">
    <title>Blood Donation</title>
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="style.css">
    <link href="script.js" rel="scriptsheet" type="text/js"/>
    <link rel="stylesheet" href="path/to/fontawesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" >

    </head>
    
<body>
    
    <section id="header">
        
        <a href="#"><img src="../images/logo_blood.png"class="logo" alt=""></a>
       
        <div>
            <ul id="navbar">
                <li><a class="active" href="home.html">Home</a></li>
                <li><a href="blood donation info.html">Blood Donation Info</a></li>
                <li><a href="search blood.html">Search Blood</a></li>
                <li><a href="https://blood-donation-49d4e.web.app/">Blood Bank near you</a></li>
                <li><a href="contact.html">About us</a></li>
                <li><a href="quiz.html"> Quiz</a></li>
                <a href="#" id="close"><i class="far fa-times"></i></a>
            </ul>
        </div>
    </section>
    
<div class="container">
    <div class="left-section">
            <form action="#">
                <label for="state" id="label">State</label>

                <input type="search" list="states" name="states" id="state" placeholder="Search state" />
                <datalist id="states">
                  <option value="Andhra Pradesh">
                  <option value="Arunachal Pradesh">
                  <option value="Assam">
                  <option value="Bihar">
                  <option value="Chhattisgarh">
                  <option value="Goa">
                  <option value="Gujarat">
                  <option value="Haryana">
                  <option value="Himachal Pradesh">
                  <option value="Jharkhand">
                  <option value="Karnataka">
                  <option value="Kerala">
                  <option value="Madhya Pradesh">
                  <option value="Maharashtra">
                  <option value="Manipur">
                  <option value="Meghalaya">
                  <option value="Mizoram">
                  <option value="Nagaland">
                  <option value="Odisha">
                  <option value="Punjab">
                  <option value="Rajasthan">
                  <option value="Sikkim">
                  <option value="Tamil Nadu">
                  <option value="Telangana">
                  <option value="Tripura">
                  <option value="Uttar Pradesh">
                  <option value="Uttarakhand">
                  <option value="West Bengal">
                </datalist>
                <input type="submit" value="Submit" onClick={handlefunc}/>
              </form>
               
    </div>
   
        import React, { useState } from 'react';

function MyComponent() {
  const [selectedOption, setSelectedOption] = useState('');

  const handleInputChange = (event) => {
    setSelectedOption(event.target.value);
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Selected option:', selectedOption);
    // Do something with the selected option
  }

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="search"
        list="states"
        name="states"
        id="state"
        placeholder="Search state"
        value={selectedOption}
        onChange={handleInputChange}
      />
      <datalist id="states">
        <option value="Andhra Pradesh" />
        <option value="Arunachal Pradesh" />
        {/* Add other options */}
      </datalist>
      <input type="submit" value="Submit" />
    </form>
  );
}

    </sript>
    <div class="right-section">
      <h2>Right Section</h2>
      <p>This is the content for the right section.</p>
    </div>
  </div>
  <style>
    .container {
  display: flex;
  flex-wrap: wrap;
}

.left-section {
  flex: 1;
  padding: 20px;
  background-color: #f0f0f0;
}

.right-section {
  flex: 1;
  padding: 20px;
  background-color: #d9d9d9;
}

  </style>
  <!--<style>
    body {
     display: flex;
     align-items: center;
     justify-content: center;
     margin: 0 auto;
     height: 100vh; 
     background-color: #f1f1f1;
   }

input {
     display: flex;
     align-items: center;
     justify-content: center;
     margin: 0 auto;
   }

label {
     display: flex;
     align-items: center;
     justify-content: center;
     margin: 0 auto;
   }

select {
     margin-bottom: 10px;
     margin-top: 10px;
   }


  </style>-->
        
</body>
</html>